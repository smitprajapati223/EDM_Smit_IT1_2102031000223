# e-learning
This is a simple Online Learing site for Programming Languages designed using Bootstrap, HTML5, CSS3, JS for front-end, MySQL for Database creation and php for back-end.
This site includes online text editor for HTML and CSS and also has experts available which can help the students in queries.
Also, has an admin panel for better control of the database and users.

Import the database in your choice of Database Tools.
The database file is located in db/project.sql.
I have used the phpmyadmin for creating and storing of my database.
