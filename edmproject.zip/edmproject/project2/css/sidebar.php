<?php echo '<pre>';?>
<h1>Index</h1>
<ul>
	<li><a href="">Chapter 1:What is CSS?</a><br></li>
	<li><a href="">Chapter 2:Three <br>Ways to Insert CSS</a><br></li>
	<li><a href="">Chapter 3:CSS <br>Colors</a><br></li>
	<li><a href="">Chapter 4:Border <br>Style</a><br></li>
	<li><a href="">Chapter 5:CSS <br>Margins</a><br></li>
	<li><a href="">Chapter 6:CSS <br>Padding</a><br></li>
</ul>
<?php echo '</pre>';?>